<?php
/**
 * @copyright   Copyright (C) 2015 Zadra Design. All rights reserved.
 * @license     GNU General Public License version 2 or later.
 */
 
defined('_JEXEC') or die;

// Include Emma
require(dirname(__FILE__) . '/lib/Emma.php');