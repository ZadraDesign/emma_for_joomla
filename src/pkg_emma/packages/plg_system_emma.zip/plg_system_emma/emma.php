<?php
/**
 * @version     1.0.0
 * @package     plg_system_emma
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 3; see LICENSE.txt
 * @author      Zadra Design <zachary@zadradesign.com> - http://zadradesign.com
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

class PlgSystemEmma extends JPlugin{
}